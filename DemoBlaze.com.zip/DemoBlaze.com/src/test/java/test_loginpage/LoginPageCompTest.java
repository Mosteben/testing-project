package test_loginpage;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import comp_loginpage.LoginPageComp;

public class LoginPageCompTest {
    private LoginPageComp loginPageComp;
    private ChromeDriver driver;

    @BeforeTest
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "\"C:\\Users\\Ali\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe\""); // Update with the path to your ChromeDriver
        driver = new ChromeDriver();
        driver.navigate().to("https://www.demoblaze.com/"); // Correct URL for Demoblaze
        driver.manage().window().maximize();
        
        loginPageComp = new LoginPageComp(driver); // Pass driver to constructor
    }

    @Test(priority = 1)
    public void testCheckLoginPageOpened() {
        loginPageComp.checkIfLoginPageOpened();
    }

    @Test(priority = 2)
    public void testVerifyPageElements() {
        loginPageComp.verifyPageElements();
    }

    @Test(priority = 3)
    public void testLoginButtonWithoutCredentials() {
        loginPageComp.testLoginButtonWithoutCredentials();
    }

    @Test(priority = 4)
    public void testSuccessfulLogin() {
        loginPageComp.testSuccessfulLogin();
    }

    @Test(priority = 5)
    public void testInvalidLogin() {
        loginPageComp.testInvalidLogin();
    }

    @Test(priority = 6)
    public void testMissingPassword() {
        loginPageComp.testMissingPassword();
    }

    @Test(priority = 7)
    public void testMissingUsername() {
        loginPageComp.testMissingUsername();
    }

    @Test(priority = 8)
    public void testLoginButtonDisabled() {
        loginPageComp.testLoginButtonDisabled();
    }

    @Test(priority = 9)
    public void testInvalidUsernameOnly() {
        loginPageComp.testInvalidUsernameOnly();
    }

    @Test(priority = 10)
    public void testInvalidPasswordOnly() {
        loginPageComp.testInvalidPasswordOnly();
    }

    @Test(priority = 11)
    public void testErrorMessageReset() {
        loginPageComp.testErrorMessageReset();
    }

    @AfterTest
    public void teardown() throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }
}
