package comp_loginpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageWebElement {
    public WebDriver driver;

    public WebElement getURL() {
        return driver.findElement(By.className("login_logo"));
    }

    public WebElement getContainer() {
        return driver.findElement(By.id("login_button_container"));
    }

    public WebElement getUserNameField() {
        return driver.findElement(By.id("user-name"));
    }

    public WebElement getUserPassField() {
        return driver.findElement(By.id("password"));
    }

    public WebElement getLoginBtn() {
        return driver.findElement(By.id("login-button"));
    }

    public WebElement getErrorMsg() {
        return driver.findElement(By.className("error-message-container"));
    }
}
