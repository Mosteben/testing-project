package comp_loginpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class LoginPageComp extends LoginPageWebElement {

    public LoginPageComp(WebDriver driver) {
        this.driver = driver; // Initialize the driver
    }

    public void checkIfLoginPageOpened() {
        String url = driver.getCurrentUrl();
        Assert.assertEquals(url, "https://www.demoblaze.com/index.html", "The current URL is incorrect.");
    }

    public void verifyPageElements() {
        Assert.assertTrue(getUserNameField().isDisplayed(), "Username field is not displayed");
        Assert.assertTrue(getUserPassField().isDisplayed(), "Password field is not displayed");
        Assert.assertTrue(getLoginBtn().isDisplayed(), "Login button is not displayed");
    }

    public void checkLoginFieldsAndContainer() {
        Assert.assertNotNull(getContainer(), "Login container is not present");
        Assert.assertNotNull(getUserNameField(), "Username field is missing");
        Assert.assertNotNull(getUserPassField(), "Password field is missing");
    }

    public void testLoginButtonWithoutCredentials() {
        WebElement loginBtn = getLoginBtn();
        loginBtn.click();

        WebElement errorMsg = getErrorMsg();
        Assert.assertTrue(errorMsg.isDisplayed(), "Error message did not appear after clicking login without credentials");
    }

    public void testSuccessfulLogin() {
        login("valid_user", "valid_password");  // Use valid user credentials
        Assert.assertEquals(driver.getCurrentUrl(), "https://www.demoblaze.com/inventory.html", "User was not redirected after successful login");
    }

    public void testInvalidLogin() {
        login("invalid_user", "invalid_password");

        WebElement errorMsg = getErrorMsg();
        Assert.assertTrue(errorMsg.isDisplayed(), "Error message did not appear for invalid credentials");
        Assert.assertEquals(errorMsg.getText(), "Username and password do not match", "Incorrect error message");
    }

    public void testMissingPassword() {
        WebElement userName = getUserNameField();
        WebElement loginBtn = getLoginBtn();

        userName.clear();
        userName.sendKeys("valid_user");
        loginBtn.click();

        WebElement errorMsg = getErrorMsg();
        Assert.assertTrue(errorMsg.isDisplayed(), "Error message did not appear when password was missing");
        Assert.assertEquals(errorMsg.getText(), "Password is required", "Incorrect error message for missing password");
    }

    public void testMissingUsername() {
        WebElement password = getUserPassField();
        WebElement loginBtn = getLoginBtn();

        password.clear();
        password.sendKeys("valid_password");
        loginBtn.click();

        WebElement errorMsg = getErrorMsg();
        Assert.assertTrue(errorMsg.isDisplayed(), "Error message did not appear when username was missing");
        Assert.assertEquals(errorMsg.getText(), "Username is required", "Incorrect error message for missing username");
    }

    public void testLoginButtonDisabled() {
        WebElement loginBtn = getLoginBtn();
        Assert.assertFalse(loginBtn.isEnabled(), "Login button should be disabled before entering credentials");
    }

    public void testInvalidUsernameOnly() {
        login("invalid_user", "valid_password");

        WebElement errorMsg = getErrorMsg();
        Assert.assertTrue(errorMsg.isDisplayed(), "Error message did not appear for invalid username");
        Assert.assertEquals(errorMsg.getText(), "Username and password do not match", "Incorrect error message");
    }

    public void testInvalidPasswordOnly() {
        login("valid_user", "invalid_password");

        WebElement errorMsg = getErrorMsg();
        Assert.assertTrue(errorMsg.isDisplayed(), "Error message did not appear for invalid password");
        Assert.assertEquals(errorMsg.getText(), "Username and password do not match", "Incorrect error message");
    }

    public void testErrorMessageReset() {
        login("invalid_user", "invalid_password"); // First attempt with invalid credentials

        WebElement errorMsg = getErrorMsg();
        Assert.assertTrue(errorMsg.isDisplayed(), "Error message did not appear for invalid credentials");

        // Now enter valid credentials
        login("valid_user", "valid_password");
        Assert.assertEquals(driver.getCurrentUrl(), "https://www.demoblaze.com/inventory.html", "User was not redirected after valid login");
    }

    private void login(String username, String password) {
        getUserNameField().clear();
        getUserNameField().sendKeys(username);
        getUserPassField().clear();
        getUserPassField().sendKeys(password);
        getLoginBtn().click();
    }
}
